<template>
  <div id="app">
    
    <router-view/>
  </div>
</template>

<script>
import router from "@/router"
export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  
}
</style>
