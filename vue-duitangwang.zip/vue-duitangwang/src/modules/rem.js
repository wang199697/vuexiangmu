document.documentElement.style.fontSize = 
    document.documentElement.clientWidth / 3.75 + "px";
    //可调任何机型
window.onresize = function(){
    document.documentElement.style.fontSize = 
    document.documentElement.clientWidth / 3.75 + "px";
}